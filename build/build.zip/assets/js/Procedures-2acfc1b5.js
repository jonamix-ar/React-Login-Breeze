import{j as r}from"./main-e1ade5b4.js";import{u as s}from"./index-db2fb923.js";const o=()=>(s(),r.jsx(r.Fragment,{children:r.jsx("h1",{children:"Bienvenido a tus causas"})}));export{o as default};
//# sourceMappingURL=Procedures-2acfc1b5.js.map
